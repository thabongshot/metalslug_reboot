#! /bin/sh
autoreconf --install --force --warnings=all #
